import api from './api';
import { CaseRecord, ProofingFinding } from '../types';

interface RawTimelineEntry {
    id: string;
    title: string;
    date: string;
    completed: boolean;
    current: boolean;
    details?: string | null;
    author?: string | null;
}

interface RawPhoto {
    id: string;
    url: string;
}

interface RawProofingQuote {
    id: string;
    reference?: string | null;
    description: string;
    technicianExplanation: string;
    findings?: string | null;
    materials?: string | null;
    materialsCost?: number | null;
    labourCost?: number | null;
    subtotal?: number | null;
    price?: number | null;
    vat: number;
    total: number;
    validUntil: string;
    status: 'pending' | 'accepted' | 'declined';
    acceptedAt?: string | null;
}

interface RawCase {
    id: string;
    referenceNumber: string;
    propertyName: string;
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    propertyAddress: string;
    postcode: string;
    pest: string;
    location: string;
    status: string;
    productName: string;
    deliveryFee: number;
    orderDate: string;
    trackingNumber?: string | null;
    courier?: string | null;
    monitoringDay: number;
    monitoringDaysTotal: number;
    activityReported?: string | null;
    activityNotes?: string | null;
    lastReportedDate?: string | null;
    appointmentDate?: string | null;
    appointmentTime?: string | null;
    appointmentStatus?: string | null;
    technicianName?: string | null;
    technicianNotes?: string | null;
    timelineEntries?: RawTimelineEntry[];
    photos?: RawPhoto[];
    proofingQuote?: RawProofingQuote | null;
}

export interface CreateCasePayload {
    propertyName: string;
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    propertyAddress: string;
    postcode: string;
    pest: string;
    location: string;
    productName: string;
    deliveryFee: number;
    courier?: string;
}

export interface UpdateCaseStatusPayload {
    status: string;
    note?: string;
}

function adaptProofingQuote(raw?: RawProofingQuote | null): CaseRecord['proofingQuote'] {
    if (!raw) return undefined;

    let findings: ProofingFinding[] | undefined;
    if (raw.findings) {
        try {
            findings = JSON.parse(raw.findings);
        } catch {
            findings = undefined;
        }
    }

    return {
        id: raw.id,
        reference: raw.reference ?? undefined,
        description: raw.description,
        technicianExplanation: raw.technicianExplanation,
        findings,
        materials: raw.materials ?? undefined,
        materialsCost: raw.materialsCost ?? undefined,
        labourCost: raw.labourCost ?? undefined,
        subtotal: raw.subtotal ?? undefined,
        price: raw.price ?? undefined,
        vat: raw.vat,
        total: raw.total,
        validUntil: raw.validUntil,
        status: raw.status,
        acceptedAt: raw.acceptedAt ?? undefined,
    };
}

export function adaptCase(raw: RawCase): CaseRecord {
    return {
        id: raw.id,
        referenceNumber: raw.referenceNumber,
        propertyName: raw.propertyName,
        customerName: raw.customerName,
        customerEmail: raw.customerEmail,
        customerPhone: raw.customerPhone,
        propertyAddress: raw.propertyAddress,
        postcode: raw.postcode,
        pest: raw.pest as CaseRecord['pest'],
        location: raw.location as CaseRecord['location'],
        status: raw.status as CaseRecord['status'],
        productName: raw.productName,
        deliveryFee: raw.deliveryFee,
        orderDate: raw.orderDate,
        trackingNumber: raw.trackingNumber ?? undefined,
        courier: raw.courier ?? '',
        monitoringDay: raw.monitoringDay,
        monitoringDaysTotal: raw.monitoringDaysTotal,
        activityReported: raw.activityReported ?? undefined,
        activityNotes: raw.activityNotes ?? undefined,
        lastReportedDate: raw.lastReportedDate ?? undefined,
        photos: raw.photos?.map((p) => p.url),
        appointmentDate: raw.appointmentDate ?? undefined,
        appointmentTime: raw.appointmentTime ?? undefined,
        appointmentStatus: (raw.appointmentStatus as CaseRecord['appointmentStatus']) ?? undefined,
        technicianName: raw.technicianName ?? undefined,
        technicianNotes: raw.technicianNotes ?? undefined,
        proofingQuote: adaptProofingQuote(raw.proofingQuote),
        timeline: (raw.timelineEntries ?? []).map((t) => ({
            title: t.title,
            date: t.date,
            completed: t.completed,
            current: t.current,
            details: t.details ?? undefined,
            author: t.author ?? undefined,
        })),
    };
}

export const CasesService = {
    async list(): Promise<CaseRecord[]> {
        const { data } = await api.get<RawCase[]>('/cases');
        return data.map(adaptCase);
    },

    async getById(id: string): Promise<CaseRecord> {
        const { data } = await api.get<RawCase>(`/cases/${id}`);
        return adaptCase(data);
    },

    async create(payload: CreateCasePayload): Promise<CaseRecord> {
        const { data } = await api.post<RawCase>('/cases', payload);
        return adaptCase(data);
    },

    async updateStatus(id: string, payload: UpdateCaseStatusPayload): Promise<CaseRecord> {
        const { data } = await api.patch<RawCase>(`/cases/${id}/status`, payload);
        return adaptCase(data);
    },

    async addTimelineEntry(id: string, title: string, details?: string): Promise<void> {
        await api.post(`/cases/${id}/timeline`, { title, details });
    },
};

export default CasesService;